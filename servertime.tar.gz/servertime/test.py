#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 14:28:44 2017

@author: aiy
"""

engine_status	gps_timestamp	speed	vehicle_id	longitude	source	latitude	heading	bmta_id	plate_id	bus_line	bus_name	status	linear_inbound	linear_outbound	linear_inbound_diff	linear_outbound_diff	outbound_fact	inbound_fact	gps_valid	idle_time	last_terminal	last_terminal_arrival	last_terminal_departure	prev_status 
	2017-07-01 10:13:04.200000	25.535	359739072722465	98.38195400000001	nakra	7.8883198333333	263.03			pothong_1	ห้างสรรพสินค้าบิ๊กซี - วิทยาลัยอาชีวศึกษาภูเก็ต	outbound	0.47572927115750796	0.5405219978157829	-0.00010766211229395999	0.00011077346893506999	3.0	0.0	1		1st_terminal	2017-07-01 08:45:54.500000	2017-07-01 10:10:48.900000	inbound 

engine_status                                                          NaN
gps_timestamp                                   2017-07-04 10:23:54.500000
speed                                                               37.059
vehicle_id                                                 359739072722465
longitude                                                          98.3686
source                                                               nakra
latitude                                                           7.89491
heading                                                             353.23
bmta_id                                                                NaN
plate_id                                                               NaN
bus_line                                                         pothong_1
bus_name                   ห้างสรรพสินค้าบิ๊กซี - วิทยาลัยอาชีวศึกษาภูเก็ต
status                                                            outbound
linear_inbound                                                    0.901857
linear_outbound                                                  0.0985842
linear_inbound_diff                                            -0.00015707
linear_outbound_diff                                           0.000163515
outbound_fact                                                            3
inbound_fact                                                             0
gps_valid                                                                1
idle_time                                                              NaN
last_terminal                                                 1st_terminal
last_terminal_arrival                           2017-07-04 08:29:13.100000
last_terminal_departure                         2017-07-04 10:22:44.400000
prev_status                                                       inbound 
Name: 344071, dtype: object

engine_status                                                          NaN
gps_timestamp                                   2017-07-04 11:32:29.815000
speed                                                                0.131
vehicle_id                                                 359739072722465
longitude                                                          98.3685
source                                                               nakra
latitude                                                           7.89605
heading                                                                 -1
bmta_id                                                                NaN
plate_id                                                               NaN
bus_line                                                         pothong_1
bus_name                   ห้างสรรพสินค้าบิ๊กซี - วิทยาลัยอาชีวศึกษาภูเก็ต
status                                                             inbound
linear_inbound                                                    0.892253
linear_outbound                                                   0.108591
linear_inbound_diff                                            1.40851e-06
linear_outbound_diff                                          -1.44307e-06
outbound_fact                                                            0
inbound_fact                                                             2
gps_valid                                                                1
idle_time                                                              NaN
last_terminal                                                 1st_terminal
last_terminal_arrival                           2017-07-04 10:24:24.500000
last_terminal_departure                         2017-07-04 11:32:01.660000
prev_status                                                      outbound 
Name: 346009, dtype: object